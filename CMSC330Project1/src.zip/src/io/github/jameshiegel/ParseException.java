package io.github.jameshiegel;

public class ParseException extends Exception {
	public ParseException(String message) {
		super(message);
	}
}