package io.github.jameshiegel;

public class GraphCycleException extends Exception {
    public GraphCycleException() {
        super();
    }
}