package io.github.jameshiegel;

public class InvalidClassException extends Exception {
    public InvalidClassException() {
        super();
    }
}